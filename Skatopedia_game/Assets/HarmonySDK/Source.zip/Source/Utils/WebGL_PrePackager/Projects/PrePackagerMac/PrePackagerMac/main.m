//
//  main.m
//  PrePackagerMac
//
//  Created by Balazs Toereki on 15/10/15.
//  Copyright © 2015 BalazsT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Python/Python.h>

NSArray* getPreloadedProjectFolders(NSString* streamingAssetsPath){
    NSString *preloadedAssetsFilePath = [NSString stringWithFormat:@"%@/PreLoadAssets.txt",streamingAssetsPath];
    NSString *contentString = [NSString stringWithContentsOfFile:preloadedAssetsFilePath encoding:NSUTF8StringEncoding error:nil];
    NSArray *contentTemp = [contentString componentsSeparatedByString:@";"];
    NSMutableArray *temp = [NSMutableArray new];
    [contentTemp enumerateObjectsUsingBlock:^(NSString *string, NSUInteger idx, BOOL * _Nonnull stop) {
        if (string.length > 0) {
            [temp addObject:string];
        }
    }];
    return temp;
}

bool checkIfDirectoryIsInPreloadedAssets(NSString *directory,NSArray *preloadedAssets){
    __block bool found = false;
    [preloadedAssets enumerateObjectsUsingBlock:^(NSString *string, NSUInteger idx, BOOL * _Nonnull stop) {
        NSRange range = [directory rangeOfString:string];
        if (range.location != NSNotFound) {
            found = true;
            *stop = YES;
        }
    }];
    return found;
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
        NSLog(@"Please set the folder in which the main webgl file exists (usually \"Development\" or \"Release\"):");
        char input[100] = {0};
        NSString *buildType;
        scanf("%s", input);
        buildType = [NSString stringWithCString:input encoding:NSUTF8StringEncoding];
        
        NSString *pyPath = @"/Applications/Unity/PlaybackEngines/WebGLSupport/BuildTools/Emscripten/tools/file_packager.py";
        if ([[NSFileManager defaultManager] fileExistsAtPath:pyPath isDirectory:NULL]) {
            NSString *currentDirectoryPath = [[NSBundle mainBundle] bundlePath];
            NSString *dirPathToCut = [NSString stringWithFormat:@"%@/",currentDirectoryPath];
            
            NSString *rootPath = [currentDirectoryPath stringByReplacingOccurrencesOfString:[currentDirectoryPath lastPathComponent] withString:@""];
            rootPath = [rootPath stringByReplacingOccurrencesOfString:[currentDirectoryPath lastPathComponent] withString:@""];
            NSString *streamingAssetsPath = [NSString stringWithFormat:@"%@/StreamingAssets",rootPath];
            NSArray *preLoadAssetsList = getPreloadedProjectFolders(streamingAssetsPath);
            
            NSFileManager *fileManager = [[NSFileManager alloc] init];
            NSURL *directoryURL = [NSURL URLWithString:currentDirectoryPath];
            NSArray *keys = [NSArray arrayWithObject:NSURLIsDirectoryKey];
            
            NSDirectoryEnumerator *enumerator = [fileManager
                                                 enumeratorAtURL:directoryURL
                                                 includingPropertiesForKeys:keys
                                                 options:0
                                                 errorHandler:^(NSURL *url, NSError *error) {
                                                     // Handle the error.
                                                     // Return YES if the enumeration should continue after the error.
                                                     return YES;
                                                 }];
            NSString *packageDataPath = [NSString stringWithFormat:@"%@%@/preLoad.data",rootPath,buildType];
            NSMutableArray *arguments = [NSMutableArray new];
            [arguments addObject:pyPath];
            [arguments addObject:packageDataPath];
            
            NSMutableArray *directoryList = [NSMutableArray new];
            NSMutableArray *existingResourceList = [NSMutableArray new];
            NSMutableArray *preLoadedDirectories = [NSMutableArray new];
            
            for (NSURL *url in enumerator) {
                NSError *error;
                NSNumber *isDirectory = nil;
                NSString *filePath = [url path];
                filePath = [filePath stringByReplacingOccurrencesOfString:dirPathToCut withString:@""];
                
                NSRange range1 = [filePath rangeOfString:@"RunExecutable"];
                NSRange range2 = [filePath rangeOfString:@"PreLoadAssets.txt"];
                NSRange range3 = [[filePath lowercaseString] rangeOfString:@".ds_store"];
                if (range1.location != NSNotFound || range2.location != NSNotFound || range3.location != NSNotFound) {
                    continue;
                }
                
                if (! [url getResourceValue:&isDirectory forKey:NSURLIsDirectoryKey error:&error]) {
                    // handle error
                }
                else if (! [isDirectory boolValue]) {
                    // file:
                    [existingResourceList addObject:filePath];
                    
                }else{
                    //directory:
                    if (checkIfDirectoryIsInPreloadedAssets(filePath, preLoadAssetsList)) {
                        [preLoadedDirectories addObject:filePath];
                    }else{
                        [directoryList addObject:filePath];
                    }
                }
            }
            
            //create existing resource list file:
            NSString *existingResourcesPath = [NSString stringWithFormat:@"%@/existingResources.txt",streamingAssetsPath];
            __block NSString *existingResourcesContent = @"";
            [existingResourceList enumerateObjectsUsingBlock:^(NSString *existingResource, NSUInteger idx, BOOL * _Nonnull stop) {
                existingResourcesContent = [NSString stringWithFormat:@"%@%@\n",existingResourcesContent,existingResource];
            }];
            [existingResourcesContent writeToFile:existingResourcesPath atomically:NO encoding:NSUTF8StringEncoding error:nil];
            
            //create Anchor:
            NSString *anchorDirectoryPath = [NSString stringWithFormat:@"%@/Anchor",streamingAssetsPath];
            NSString *anchorTxtPath = [NSString stringWithFormat:@"%@/Anchor.txt",anchorDirectoryPath];
            
            [[NSFileManager defaultManager]createDirectoryAtPath:anchorDirectoryPath withIntermediateDirectories:NO attributes:nil error:nil];
            
            NSString *emptyString = @"";
            [emptyString writeToFile:anchorTxtPath atomically:NO encoding:NSUTF8StringEncoding error:nil];
            
            //add Anchor directory to preload:
            [arguments addObject:@"--preload"];
            [arguments addObject:@"Anchor/"];
            
            //add set preloaded Assets to preload:
            [preLoadedDirectories enumerateObjectsUsingBlock:^(NSString *directory, NSUInteger idx, BOOL * _Nonnull stop) {
                [arguments addObject:@"--preload"];
                [arguments addObject:directory];
            }];
            
            //add existing resource to preload:
            [arguments addObject:@"--preload"];
            [arguments addObject:@"existingResources.txt"];
            
            //add PreLoadAssets.txt resource to preload:
            [arguments addObject:@"--preload"];
            [arguments addObject:@"PreLoadAssets.txt"];
            
            NSString *jsOutput = [NSString stringWithFormat:@"--js-output=%@%@/preLoad.js",rootPath,buildType];
            [arguments addObject:jsOutput];
            
            NSPipe *pipe = [NSPipe pipe];
            NSFileHandle *file = pipe.fileHandleForReading;
            
            NSTask *task = [[NSTask alloc] init];
            task.launchPath = @"/usr/bin/python";
            task.arguments = arguments;
            task.standardOutput = pipe;
            task.currentDirectoryPath = currentDirectoryPath;
            
            [task launch];
            
            NSData *data = [file readDataToEndOfFile];
            [file closeFile];
            
            NSString *output = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding];
            NSLog (@"output returned:\n%@", output);
            
            //prepackage done, remove anchor fake directory/file
            [[NSFileManager defaultManager]removeItemAtPath:anchorDirectoryPath error:nil];
            
            //prePackage done, extend index.html:
            NSString *indexHTMLPath = [NSString stringWithFormat:@"%@index.html",rootPath];
            NSMutableString *indexHTML = [NSMutableString stringWithContentsOfFile:indexHTMLPath encoding:NSUTF8StringEncoding error:NULL];
            
            
            NSString *markToFind = [NSString stringWithFormat:@"</body>"];
            NSString *scriptToAdd = [NSString stringWithFormat:@"<script src=\"%@/preLoad.js\"></script>\n",buildType];
            
            NSRange rangeSTA = [indexHTML rangeOfString:scriptToAdd];
            if (rangeSTA.location == NSNotFound) {
                NSRange range = [indexHTML rangeOfString:markToFind];
                [indexHTML insertString:scriptToAdd atIndex:(range.location)];
                
                [indexHTML writeToFile:indexHTMLPath atomically:NO encoding:NSUTF8StringEncoding error:nil];
            }
            
            //add directory preloading to preload.js:
            __block NSString *directoryHierarchyPreload = @"";
            [directoryList enumerateObjectsUsingBlock:^(NSString *directory, NSUInteger idx, BOOL * _Nonnull stop) {
                directoryHierarchyPreload = [NSString stringWithFormat:@"%@\nModule['FS_createPath']('/', '%@', true, true);",directoryHierarchyPreload,directory];
            }];
            NSString *anchorPoint = @"Module['FS_createPath']('/', 'Anchor', true, true);";
            NSString *preloadJSFilePath = [NSString stringWithFormat:@"%@%@/preLoad.js",rootPath,buildType];
            NSMutableString *preloadJSFileContent = [NSMutableString stringWithContentsOfFile:preloadJSFilePath encoding:NSUTF8StringEncoding error:nil];
            //fix for unity compatibility:
            NSError *error = NULL;
            NSRegularExpression *regex = [NSRegularExpression
                                          regularExpressionWithPattern:@"var REMOTE_PACKAGE_NAME = typeof Module\\['locateFile'\\] =* 'function' \\? *\\n *Module\\['locateFile'\\]\\(REMOTE_PACKAGE_BASE\\) : *\\n *\\(\\(Module\\['filePackagePrefixURL'\\] \\|\\| ''\\) \\+ REMOTE_PACKAGE_BASE\\);"
                                          options:NSRegularExpressionCaseInsensitive
                                          error:&error];
            __block NSRange range;
            __block bool found = false;
            [regex enumerateMatchesInString:preloadJSFileContent options:0 range:NSMakeRange(0, [preloadJSFileContent length]) usingBlock:^(NSTextCheckingResult *match, NSMatchingFlags flags, BOOL *stop){
                // your code to handle matches here
                range = match.range;
                found = TRUE;
                *stop = YES;
            }];
            
            if (found) {
                preloadJSFileContent = [[preloadJSFileContent stringByReplacingCharactersInRange:range withString:[NSString stringWithFormat:@"var REMOTE_PACKAGE_NAME = \"%@/\" + REMOTE_PACKAGE_BASE;",buildType]] mutableCopy];
                
                [preloadJSFileContent writeToFile:preloadJSFilePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
            }
            
            
            
            NSRange rangeAnchor = [preloadJSFileContent rangeOfString:anchorPoint];
            if (rangeAnchor.location != NSNotFound) {
                [preloadJSFileContent insertString:directoryHierarchyPreload atIndex:(rangeAnchor.location+rangeAnchor.length)];
                [preloadJSFileContent writeToFile:preloadJSFilePath atomically:NO encoding:NSUTF8StringEncoding error:nil];
                NSLog(@"Your Web page is ready to use.");
            }else{
                NSLog(@"Anchor point not found in preLoad.js");
            }
            
        }else{
            NSLog(@"file packager does not exist at give path");
        }
    }
    return 0;
}
