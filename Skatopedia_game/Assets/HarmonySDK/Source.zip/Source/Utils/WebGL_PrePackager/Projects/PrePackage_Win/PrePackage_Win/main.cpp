#include <stdio.h>  /* defines FILENAME_MAX */
#ifndef WINDOWS
	#define WINDOWS
#endif
#ifdef WINDOWS
    #include <direct.h>
    #define GetCurrentDir _getcwd
#else
    #include <unistd.h>
    #define GetCurrentDir getcwd
 #endif


#include <windows.h>
#include <string>
#include <iostream>
#include <fstream>
#include <list>
#include <algorithm>
#include <regex>

using namespace std ;

std::string getCurrentDirectory(){
	char cCurrentPath[FILENAME_MAX];

	if (!GetCurrentDir(cCurrentPath, sizeof(cCurrentPath)))
    {
		return "";
    }

	cCurrentPath[sizeof(cCurrentPath) - 1] = '\0'; /* not really required */
	return std::string(cCurrentPath);;
}
/////////////////////
static std::list<std::string> toBePreloadedAssetsList;
void getPreloadAssetsList(std::string rootPath){
	std::ifstream myfile(rootPath+"\\StreamingAssets\\PreLoadAssets.txt");
	std::string line;
	if (!myfile.is_open()){
		return;
	}
	while (!myfile.eof()){
		getline(myfile,line,';');
		if (line.length() > 0){
			int lineLength = line.length();
			char lastChar = line[line.length()-1];
			if (lastChar ==';'){
				line = line.substr(0,line.length()-1);
			}
			lineLength = line.length();
			std::replace( line.begin(), line.end(), '/', '\\'); // replace all '\\' to '/'
			if (line[0]=='\\'){
				line = line.substr(1,line.length());
			}
			toBePreloadedAssetsList.push_back(line);
		}
	}
	myfile.close();
}

bool checkIfFileIsInPreloadedAssets(std::string filePath){
	std::string temp = "";
	bool found = false;
	for(std::list<std::string>::iterator it = toBePreloadedAssetsList.begin(); it!=toBePreloadedAssetsList.end();++it)
	{
		temp = *it;
		if (filePath.find(temp) != std::string::npos){
			found = true;
			break;
		}
	}
	return found;
}

void listDir(std::list<std::string>& preloadedAssetsListing,const char * dirn,std::list<std::string>& listing,std::string &originalPath,std::list<std::string>& folderPaths)
{
    char dirnPath[1024];
    sprintf(dirnPath, "%s\\*", dirn);

    WIN32_FIND_DATA f;
    HANDLE h = FindFirstFile(dirnPath, &f);

    if (h == INVALID_HANDLE_VALUE) { return; }

    do
    {
        const char * name = f.cFileName;

        if (strcmp(name, ".") == 0 || strcmp(name, "..") == 0) { continue; }

		std::string fName = name;
		if (fName.find(".exe") != std::string::npos) { continue;}
		std::string slash = "\\";
		std::string filePath = dirn + slash + name;

        if (f.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)
        {
			std::string nfilePath = filePath.substr(originalPath.length()+1);
			if (nfilePath.find("RunExecutable") == std::string::npos){
				//check if folder is in PreloadAssetsList
				if (checkIfFileIsInPreloadedAssets(nfilePath)){
					preloadedAssetsListing.push_back(nfilePath);
				}else{
					folderPaths.push_back(nfilePath);
				}

				listDir(preloadedAssetsListing,filePath.c_str(),listing,originalPath,folderPaths);
			}
        }else{
			std::size_t pos = filePath.find(originalPath);
			if (pos != std::string::npos){
				pos = filePath.find("PreLoadAssets.txt");
				if (pos == std::string::npos){
					std::string nfilePath = filePath.substr(originalPath.length()+1);
					listing.push_back(nfilePath);
				}
			}
		}
    } while (FindNextFile(h, &f));
    FindClose(h);
}
///

bool is_file_exist(const char *fileName)
{
    std::ifstream infile(fileName);
    return infile.good();
}

std::string getStreamingAssetsPath(std::string path){
	std::string StreamingAssetsStr = "StreamingAssets";
	std::size_t pos = path.find(StreamingAssetsStr.c_str());
	if (pos != std::string::npos){
		path = path.substr(0,pos+StreamingAssetsStr.length());
		return path;
	}else{
		return "";
	}
}

std::string getRootPath(std::string path){
	std::string StreamingAssetsStr = "\\StreamingAssets";
	std::size_t pos = path.find(StreamingAssetsStr.c_str());
	if (pos != std::string::npos){
		path = path.substr(0,pos);
		return path;
	}else{
		return "";
	}
}

int main() {
	std::cout<<"Please set the folder in which the main webgl file exists (usually \"Development\" or \"Release\"):"<<std::endl;
	std::string PeckagePrefilURL;
	std::getline(cin,PeckagePrefilURL);
	//

	std::string currentDirectory = getCurrentDirectory();
	std::string streamingAssetsPath = getStreamingAssetsPath(currentDirectory);
	std::string rootPath = getRootPath(currentDirectory);
	if (streamingAssetsPath.length() == 0 || rootPath.length() == 0){
		std::ofstream out(currentDirectory + "\\debug.txt");
		out<<"StreamingAssets or \"root\" folder path could not be found!"<<std::endl;
		out<<"Please check if \"RunExecutable\" folder is in original structure."<<std::endl;
		out.close();
		return -1;
	}
	std::string pyPath = "C:\\Program Files\\Unity\\Editor\\Data\\PlaybackEngines\\webglsupport\\BuildTools\\Emscripten\\tools\\file_packager.py";
	if (!is_file_exist(pyPath.c_str())){
		std::string userSetPyPathFilePath = currentDirectory+ "\\file_packer_py_Path.txt";
		std::ifstream ifs(userSetPyPathFilePath);

		std::string userSetPyPath( (std::istreambuf_iterator<char>(ifs) ),
                                   (std::istreambuf_iterator<char>()    ) );

		pyPath = userSetPyPath;

		if (!is_file_exist(pyPath.c_str())){
			std::ofstream out(currentDirectory + "\\debug.txt");
			out<<"File Packager not found!\nPlease set the file_packager.py file's path correctly in the txt file.\n"<<std::endl;
			out<<"You should be able to find it at path:"<<std::endl;
			out<<"..Unity(Install location)\\Editor\\Data\\PlaybackEngines\\webglsupport\\BuildTools\\Emscripten\\tools"<<std::endl;
			out<<std::endl;
			out<<"Currently set path is:"<<std::endl;
			out<<pyPath<<std::endl;
			out.close();
			return -1;
		}
	};
	//init toBePreloadedAssetsList
	getPreloadAssetsList(rootPath);

	std::list<std::string> filePaths;
	std::list<std::string> folderPaths;
	std::list<std::string> preloadedAssetsListing;
	listDir(preloadedAssetsListing,streamingAssetsPath.c_str(),filePaths,streamingAssetsPath,folderPaths);
	
	std::string moveToStreamingAssetsPath = "cd " + streamingAssetsPath + "&&";
	std::string command = moveToStreamingAssetsPath;
	command += "python ";
	command += "\"";
	command += pyPath;
	command +=	"\" ";
	command += "\"";
	command += rootPath+"\\"+PeckagePrefilURL+"\\preLoaded.data";
	command += "\" ";

	std::string anchorFolderPath = rootPath+"\\StreamingAssets\\Anchor";
	_mkdir(anchorFolderPath.c_str());
	std::string anchorFilePath = anchorFolderPath + "\\Anchor.txt";
	std::ofstream anchorFile(anchorFilePath);
	anchorFile.close();
	std::string existingResourcesPath = rootPath+"\\StreamingAssets\\existingResources.txt";
	std::ofstream existingResourcesFile(existingResourcesPath);
	std::string forCharacterSwap = "";
	for(std::list<std::string>::iterator it = filePaths.begin(); it!=filePaths.end();++it)
	{
		forCharacterSwap = *it;
		std::replace( forCharacterSwap.begin(), forCharacterSwap.end(), '\\', '/'); // replace all '\\' to '/'
		existingResourcesFile<<forCharacterSwap<<"\n";
		continue;
	}
	for(std::list<std::string>::iterator it = preloadedAssetsListing.begin(); it!=preloadedAssetsListing.end();++it)
	{
		command += "--preload \"";
		command += *it;
		command += "\" ";
	}
	
	command += "--preload \"";
	command += "Anchor/";
	command += "\" ";

	existingResourcesFile.close();
	{
		command += "--preload \"";
		command += "existingResources.txt";
		command += "\" ";
	}
	{
		command += "--preload \"";
		command += "PreLoadAssets.txt";
		command += "\" ";
	}
	
	command += "--js-output=\"";
	command += rootPath+"\\"+PeckagePrefilURL+"\\preLoad.js\"";
	system(command.c_str());

	//
	remove(anchorFilePath.c_str());
	_rmdir(anchorFolderPath.c_str());

	std::string preLoadJSFilePath = rootPath+"\\"+PeckagePrefilURL+"\\preLoad.js";
	if (!is_file_exist(preLoadJSFilePath.c_str())){
		std::ofstream out(currentDirectory + "\\debug.txt");
		out<<"Pre Packiging has failed."<<std::endl;
		out<<"Please check if you have original StreamingAssets-RunExecutable structure."<<std::endl;
		out<<"If all above fails,please contact support."<<std::endl;
		out.close();
		return -1;
	}

	//fix issue where REMOTE_PACKAGE_NAME gets overwritten by unity's new script:

	std::ifstream preLoadJSFilePathIFS(preLoadJSFilePath);
	std::string preLoadJSFileString( (std::istreambuf_iterator<char>(preLoadJSFilePathIFS) ),
                                (std::istreambuf_iterator<char>()    ) );

	preLoadJSFilePathIFS.close();

	regex regularExpression("var REMOTE_PACKAGE_NAME = typeof Module\\['locateFile'\\] =* 'function' \\? *\\n *Module\\['locateFile'\\]\\(REMOTE_PACKAGE_BASE\\) : *\\n *\\(\\(Module\\['filePackagePrefixURL'\\] \\|\\| ''\\) \\+ REMOTE_PACKAGE_BASE\\);");
	smatch result;
	regex_search(preLoadJSFileString,result,regularExpression);
	
	if (result.size()>0){
		preLoadJSFileString.erase(result.position(0),result[0].length());
		preLoadJSFileString.insert(result.position(0),"var REMOTE_PACKAGE_NAME = \"" + PeckagePrefilURL + "/\" + REMOTE_PACKAGE_BASE;");
	}

	/////////

	//add folder path creation to JS:
	std::string additionalFolderPaths = "";
	std::string forCharacterSwapping = "";
	for(std::list<std::string>::iterator it = folderPaths.begin(); it!=folderPaths.end();++it)
	{
		forCharacterSwapping = *it;
		std::replace( forCharacterSwapping.begin(), forCharacterSwapping.end(), '\\', '/'); // replace all '\\' to '/'
		additionalFolderPaths += "\nModule['FS_createPath']('/', '" + forCharacterSwapping + "', true, true);";
	}
	std::string anchorPoint = "Module['FS_createPath']('/', 'Anchor', true, true);";

	std::size_t anchorPointLocation = preLoadJSFileString.find(anchorPoint);
	if (anchorPointLocation == std::string::npos){
		std::ofstream out(currentDirectory + "\\debug.txt");
		out<<"Failed to update index.html file with Preload Data set..."<<std::endl;
		out<<"Please check if \"RunExecutable\" folder is in original structure."<<std::endl;
		out<<"And if \"index.html\" can be found in the root directory."<<std::endl;
		out.close();
		return -1;
	}

	std::size_t addFolderPs = preLoadJSFileString.find(additionalFolderPaths);
	if (addFolderPs == std::string::npos){
		preLoadJSFileString.insert(anchorPointLocation+anchorPoint.length(),additionalFolderPaths);
		std::ofstream preLoadJSFileStringOUT(preLoadJSFilePath);
		preLoadJSFileStringOUT<<preLoadJSFileString;
		preLoadJSFileStringOUT.close();
	}

	/////////

	std::string indexHTMLFilePath = rootPath+ "\\index.html";
	std::ifstream ifs(indexHTMLFilePath);
	std::string indexHTMLContent( (std::istreambuf_iterator<char>(ifs) ),
                                (std::istreambuf_iterator<char>()    ) );

	ifs.close();
	
	std::string loadCallToFind = "</body>";

	std::size_t posLoadCallToFind = indexHTMLContent.find(loadCallToFind);
	if (posLoadCallToFind == std::string::npos){
		std::ofstream out(currentDirectory + "\\debug.txt");
		out<<"Failed to update index.html file with Preload Data set..."<<std::endl;
		out<<"Please check if \"RunExecutable\" folder is in original structure."<<std::endl;
		out<<"And if \"index.html\" can be found in the root directory."<<std::endl;
		out.close();
		return -1;
	}

	std::string loadCall = "<script src=\"" + PeckagePrefilURL + "/preLoad.js\"></script>\n";

	std::size_t posLoadCall = indexHTMLContent.find(loadCall);
	if (posLoadCall == std::string::npos){
		indexHTMLContent.insert(posLoadCallToFind,loadCall);

		std::ofstream out(rootPath+"\\index.html");
		out<<indexHTMLContent;
		out.close();
	}

	

	{
		//success:
		std::ofstream out(currentDirectory + "\\success.txt");
		out<<"Pre Packaging has succeeded."<<std::endl;
		out<<"Your WebGL webpage is ready to use."<<std::endl;
		out.close();
	}

	return 1;
}