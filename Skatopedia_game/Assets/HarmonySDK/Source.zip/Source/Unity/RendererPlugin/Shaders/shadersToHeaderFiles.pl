#!/usr/bin/perl -w

# Convert all shader files to char array in separate header files.
# This prevents having to package shader files as resources alongside
# the plugin.

use strict;
use warnings;
use File::Path;
use File::Basename;

use Env qw($DXSDK_DIR);

my @extToHeader = (
  ".glsl",
  ".hlsl",
  ".metal"
);

my %extToHeaderMap = map { $_ => 1 } @extToHeader;

my @extToCso = (
  ".hlsl"
);

my %extToCsoMap = map { $_ => 1 } @extToCso;


if ( $^O eq "MSWin32" or $^O eq "cygwin" )
{
  opendir(DIR, ".") or die $!;

  my $FXC_EXE = "$DXSDK_DIR/Utilities/bin/x86/fxc.exe";
  unless (-e $FXC_EXE)
  {
    print "WARNING: Could not find fxc.exe.\nMake sure you have a working installation of DirectX SDK to compile this plugin.\n";
  }
  else
  {

    while (my $file = readdir(DIR))
    {
      # Use a regular expression to ignore files beginning with a period
      next if ($file =~ m/^\./);
      #print $file . "\n";

      my($basename, $directories, $extension) = fileparse($file, qr/\.[^.]*/);
      #print $basename . " " . $directories . " " . $extension . "\n";

      if (exists($extToCsoMap{$extension}))
      {
        my $variable_name = "g_" . $basename . ".cso";
        $variable_name =~ s/\./_/g;

        my $shader_type = (index($basename, "Vert") != -1) ? "vs" : "ps";
        my $shader_version = (index($basename, "DX9") != -1) ? "_2_0" : "_4_0";

        my $shader_profile = $shader_type . $shader_version;

        system( $FXC_EXE,
                "/T", $shader_profile,
                "/Vn", $variable_name,
                "/Fh", $directories . $basename . ".cso.h",
                $file ) == 0 or die "Could not compile shader $file."
      }
    }
  }

  closedir(DIR);
}

opendir(DIR, ".") or die $!;

while (my $file = readdir(DIR))
{
  # Use a regular expression to ignore files beginning with a period
  next if ($file =~ m/^\./);
  #print $file . "\n";

  my($basename, $directories, $extension) = fileparse($file, qr/\.[^.]*/);
  #print $basename . " " . $directories . " " . $extension . "\n";

  if (exists($extToHeaderMap{$extension}))
  {
    open(INFILE, "<", $file) or die "Could not open input stream to $file: $!";
    open(OUTFILE, ">", $file . ".h" ) or die "Could not open output stream to $file.h: $!";

    my $header_macro = "__" . uc($file) . "_H__";
    $header_macro =~ s/\./_/g;

    my $variable_name = "g_" . $file;
    $variable_name =~ s/\./_/g;

    print OUTFILE "#ifndef $header_macro\n";
    print OUTFILE "#define $header_macro\n\n";

    print OUTFILE "const char *$variable_name =\n";
    print OUTFILE "\"\\n\\\n";

    while (<INFILE>)
    {
      $_ =~ s/(.*)$/$1\\n\\/;
      print OUTFILE $_;
    }

    print OUTFILE "\";\n\n";

    print OUTFILE "#endif /* $header_macro */";

    close(INFILE);
    close(OUTFILE);
  }
}

closedir(DIR);
