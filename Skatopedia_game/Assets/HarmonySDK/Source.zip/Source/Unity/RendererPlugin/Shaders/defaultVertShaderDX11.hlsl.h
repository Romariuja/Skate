#ifndef __DEFAULTVERTSHADERDX11_HLSL_H__
#define __DEFAULTVERTSHADERDX11_HLSL_H__

const char *g_defaultVertShaderDX11_hlsl =
"\n\
\n\
struct InputVertex\n\
{\n\
  float3 a_position       : POSITION;\n\
  float4 a_color          : COLOR;\n\
  float2 a_texCoord0      : TEXCOORD0;\n\
};\n\
struct OutputVertex\n\
{\n\
  float4 v_position       : SV_POSITION;\n\
  float4 v_color          : COLOR;\n\
  float2 v_texCoord0      : TEXCOORD0;\n\
};\n\
\n\
cbuffer ConstantBuffer : register(b0)\n\
{\n\
  float4x4 u_mvpMatrix;\n\
}\n\
\n\
OutputVertex main( InputVertex i_vertex )\n\
{\n\
  OutputVertex o_vertex;\n\
\n\
  o_vertex.v_position = mul( u_mvpMatrix, float4( i_vertex.a_position, 1.0f ) );\n\
  //o_vertex.v_position = mul( float4( i_vertex.a_position, 1.0f ), u_mvpMatrix );\n\
  o_vertex.v_color = i_vertex.a_color.bgra;\n\
  o_vertex.v_texCoord0 = i_vertex.a_texCoord0;\n\
\n\
  return o_vertex;\n\
}\n\
\n\
";

#endif /* __DEFAULTVERTSHADERDX11_HLSL_H__ */