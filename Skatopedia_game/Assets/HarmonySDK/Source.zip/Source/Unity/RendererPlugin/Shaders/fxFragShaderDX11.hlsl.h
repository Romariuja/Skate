#ifndef __FXFRAGSHADERDX11_HLSL_H__
#define __FXFRAGSHADERDX11_HLSL_H__

const char *g_fxFragShaderDX11_hlsl =
"\n\
\n\
//  v_fxParams ( cutter and inverse cutter )\n\
//  | u               | v               | add             | mult            |\n\
//  |-----------------|-----------------|-----------------|-----------------|\n\
//  | (float) 32 bits | (float) 32 bits | (float) 32 bits | (float) 32 bits |\n\
\n\
//  v_fxViewport\n\
//  | u0              | v0              | u1              | v1              |\n\
//  |-----------------|-----------------|-----------------|-----------------|\n\
//  | (float) 32 bits | (float) 32 bits | (float) 32 bits | (float) 32 bits |\n\
\n\
struct OutputVertex\n\
{\n\
  float4 v_position                     : POSITION;\n\
  float4 v_color                        : COLOR;\n\
  float2 v_texCoord0                    : TEXCOORD0;\n\
\n\
  float4 v_fxParams0                    : TEXCOORD1;\n\
  nointerpolation float4 v_fxViewport0  : TEXCOORD2;\n\
};\n\
\n\
SamplerState TextureSampler\n\
{\n\
  Filter = MIN_MAG_LINEAR;\n\
  AddressU = Clamp;\n\
  AddressV = Clamp;\n\
};\n\
\n\
void applyCutter( in Texture2D maskTexture, in float4 fxParams, in float4 fxViewport, inout float mult )\n\
{\n\
  //if ( fxParams.w == 0.0 )\n\
  //{\n\
  //  mult *= fxParams.z;\n\
  //  return;\n\
  //}\n\
\n\
  //  Clamp uv coordinates once they are outside of matte viewport.\n\
  //  This takes into account that last pixel bands are entirely\n\
  //  transparent.\n\
  float2 uv = clamp( fxParams.xy, fxViewport.xy, fxViewport.zw );\n\
  mult *= (fxParams.z + fxParams.w * maskTexture.Sample( TextureSampler, uv ).a);\n\
}\n\
\n\
Texture2D u_mainTexture;\n\
\n\
float4 main( OutputVertex i_vertex ) : SV_TARGET\n\
{\n\
  float mult = 1.0;\n\
\n\
  applyCutter( u_mainTexture, i_vertex.v_fxParams0, i_vertex.v_fxViewport0, mult );\n\
\n\
  return (i_vertex.v_color * mult * u_mainTexture.Sample( TextureSampler, i_vertex.v_texCoord0));\n\
}\n\
\n\
";

#endif /* __FXFRAGSHADERDX11_HLSL_H__ */