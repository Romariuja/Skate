#ifndef __DEFAULTFRAGSHADERDX11_HLSL_H__
#define __DEFAULTFRAGSHADERDX11_HLSL_H__

const char *g_defaultFragShaderDX11_hlsl =
"\n\
\n\
struct OutputVertex\n\
{\n\
  float4 v_position      : POSITION;\n\
  float4 v_color         : COLOR;\n\
  float2 v_texCoord0     : TEXCOORD0;\n\
};\n\
\n\
Texture2D u_mainTexture;\n\
\n\
SamplerState TextureSampler\n\
{\n\
  Filter = MIN_MAG_LINEAR;\n\
  AddressU = Clamp;\n\
  AddressV = Clamp;\n\
};\n\
\n\
float4 main( OutputVertex i_vertex ) : SV_TARGET\n\
{\n\
  return (i_vertex.v_color * u_mainTexture.Sample( TextureSampler, i_vertex.v_texCoord0));\n\
}\n\
\n\
";

#endif /* __DEFAULTFRAGSHADERDX11_HLSL_H__ */