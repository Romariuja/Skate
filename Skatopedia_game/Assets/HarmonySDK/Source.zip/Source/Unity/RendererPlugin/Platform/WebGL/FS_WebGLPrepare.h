#ifndef _FS_WEBGLPREPARE_H_
#define _FS_WEBGLPREPARE_H_
#include "PL_Configure.h"

#ifdef TARGET_WEBGL

#include <vector>
#include <map>
#include <string>


///////////////////
///ACCESSABLE RE///
///////////////////
//singleton for tracking accessable resources
class SingletonAccessableResources
{
private:
    static bool instanceFlag;
    static SingletonAccessableResources *singletonAccessableResources;
    SingletonAccessableResources()
    {
        //private constructor
    }
public:
	std::vector<std::string> accessableResourcesList;
    static SingletonAccessableResources* getInstance();
    ~SingletonAccessableResources()
    {
        instanceFlag = false;
    }

	//functions:
	void PrepareAccessableResourceList();
};
///////////////////
///   RESOURCE  ///
///////////////////
struct Resource{
	std::string resourceName;
	std::vector<std::string> fileNames;
};

//singleton for tracking resources
class SingletonResource
{
private:
    static bool instanceFlag;
    static SingletonResource *singletonResources;
    SingletonResource()
    {
        //private constructor
    }
public:
	std::vector<Resource> resourcesList;
    static SingletonResource* getInstance();
    ~SingletonResource()
    {
        instanceFlag = false;
    }

	//functions:
	void PrepareResources();
	bool ResourceExists(std::string resourceName);
};

///////////////////
/// PREPARATION ///
///////////////////
struct ResourceBeingPrepared{
	std::string resourceName;
	std::vector<std::string> resourceFiles;
	int idx;
};

//singleton for tracking resources being prepared
class SingletonPreparation
{
private:
    static bool instanceFlag;
    static SingletonPreparation *singletonPreparation;
    SingletonPreparation()
    {
        //private constructor
    }
public:
	std::vector<ResourceBeingPrepared> resourcesList;
    static SingletonPreparation* getInstance();
    ~SingletonPreparation()
    {
        instanceFlag = false;
    }

	//functions:
	int getIndexForResourceFile(std::string resourceFile);
	int getIndexForResourceName(std::string resourceName);
};

//singleton for tracking failed perparations
class SingletonFailedPreparation
{
private:
	static bool instanceFlag;
	static SingletonFailedPreparation *singletonFailedPreparation;
	SingletonFailedPreparation()
	{
	}
public:
	std::vector<std::string> failedResourcesList;
	static SingletonFailedPreparation* getInstance();
	~SingletonFailedPreparation()
	{
		instanceFlag = false;
	}
	//functions:
	bool isResourceFailedPreparation(std::string resourceName);
	void removeResourceFromFailedPreparations(std::string resourceName);
};

#endif

#endif/* _FS_WEBGLPREPARE_H_ */