#include "FS_WebGLPrepare.h"

#ifdef TARGET_WEBGL
#include<stdio.h>
#include<emscripten.h>
#include<assert.h>
#include<string>
#include <fstream>

#define  LOGFS(...)  fprintf(stderr, "[%s] ", "LOG_FS" );   fprintf(stderr, __VA_ARGS__)

#ifndef EXPORT_API
	#if !(defined(UNITY_WIN) || defined(UNITY_OSX))
		// Which platform we are on?
		#if _MSC_VER
			#define UNITY_WIN 1
		#else
			#define UNITY_OSX 1
		#endif
	#endif

	// Attribute to make function be exported from a plugin
	#if UNITY_WIN
		#define EXPORT_API __declspec(dllexport)
	#else
		#define EXPORT_API
	#endif
#endif



///////////////////
///////////////////
///////////////////
//create singleton for existing resources:
	bool SingletonAccessableResources::instanceFlag = false;
	SingletonAccessableResources* SingletonAccessableResources::singletonAccessableResources = NULL;
	SingletonAccessableResources* SingletonAccessableResources::getInstance()
	{
		if(! instanceFlag)
		{
			instanceFlag = true;
			singletonAccessableResources = new SingletonAccessableResources();
			singletonAccessableResources->accessableResourcesList.clear();
			singletonAccessableResources->PrepareAccessableResourceList();

			return singletonAccessableResources;
		}
		else
		{
			return singletonAccessableResources;
		}
	}
	void SingletonAccessableResources::PrepareAccessableResourceList(){
		if (accessableResourcesList.size()>0){
			return;
		}
		std::ifstream myfile("/existingResources.txt");
		std::string line;
		if (!myfile.is_open()){
			return;
		}
		while (!myfile.eof()){
			getline(myfile,line);
			if (line.length() > 0){
				//remove carrige return character:
				if (line[line.length()-1]=='\r'){
					line = line.substr(0,line.length()-1);
				}
				accessableResourcesList.push_back(line);
			}
		}
		myfile.close();
	}
	void getResourceFilesForResourceFolder(std::string resourceNameFolder,std::vector<std::string> &resourceFiles){
		SingletonAccessableResources *ar = SingletonAccessableResources::getInstance();
		for (int i = 0;i < ar->accessableResourcesList.size();i++){
			if (ar->accessableResourcesList[i].find(resourceNameFolder)!=std::string::npos){
				resourceFiles.push_back(ar->accessableResourcesList[i]);
			}
		}
	}
///////////////////
///////////////////
///////////////////
//create singleton for storing downloaded resources
	bool SingletonResource::instanceFlag = false;
	SingletonResource* SingletonResource::singletonResources = NULL;
	SingletonResource* SingletonResource::getInstance()
	{
		if(! instanceFlag)
		{
			singletonResources = new SingletonResource();
			singletonResources->resourcesList.clear();
			singletonResources->PrepareResources();

			instanceFlag = true;
			return singletonResources;
		}
		else
		{
			return singletonResources;
		}
	}
	bool SingletonResource::ResourceExists(std::string resourceName){
		bool exists = false;
		for(int i = 0;i<resourcesList.size();i++){
			if (resourceName.compare(resourcesList[i].resourceName)==0){
				exists = true;
				break;
			}
		}
		return exists;
	}
	void SingletonResource::PrepareResources(){
		if (resourcesList.size()>0){
			return;
		}
		std::ifstream myfile("/PreLoadAssets.txt");
		std::string line;
		if (!myfile.is_open()){
			return;
		}
		while (!myfile.eof()){
			getline(myfile,line,';');
			if (line.length() > 0){
				Resource temp;
				temp.resourceName = line;
				
				getResourceFilesForResourceFolder(temp.resourceName+"/",temp.fileNames);
				
				resourcesList.push_back(temp);
			}
		}
		myfile.close();
		
	}
///////////////////
///////////////////
///////////////////
//create singleton for storing downloading resources
	bool SingletonPreparation::instanceFlag = false;
	SingletonPreparation* SingletonPreparation::singletonPreparation = NULL;
	SingletonPreparation* SingletonPreparation::getInstance()
	{
		if(! instanceFlag)
		{
			singletonPreparation = new SingletonPreparation();
			singletonPreparation->resourcesList.clear();
			instanceFlag = true;
			return singletonPreparation;
		}
		else
		{
			return singletonPreparation;
		}
	}
	int SingletonPreparation::getIndexForResourceName(std::string resourceName){
		int idx = -1;
		for(int i = 0;i<resourcesList.size();i++){
			if (resourceName.compare(resourcesList[i].resourceName)==0){
				idx = i;
				break;
			}
		}
		return idx;
	}
	int SingletonPreparation::getIndexForResourceFile(std::string resourceFile){
		int idx = -1;
		for (int i = 0; i<resourcesList.size();i++){
			for (int j = 0;j<resourcesList[i].resourceFiles.size();j++){
				if (resourceFile.compare(resourcesList[i].resourceFiles[j])==0){
					idx = i;
					break;
				}
			}
			if (idx > -1){
				break;
			}
		}
		return idx;
	}
///////////////////
///////////////////
///////////////////
	bool SingletonFailedPreparation::instanceFlag = false;
	SingletonFailedPreparation* SingletonFailedPreparation::singletonFailedPreparation = NULL;
	SingletonFailedPreparation* SingletonFailedPreparation::getInstance()
	{
		if(! instanceFlag)
		{
			singletonFailedPreparation = new SingletonFailedPreparation();
			singletonFailedPreparation->failedResourcesList.clear();
			instanceFlag = true;
			return singletonFailedPreparation;
		}
		else
		{
			return singletonFailedPreparation;
		}
	}
	//functions:
	bool SingletonFailedPreparation::isResourceFailedPreparation(std::string resourceName){
		bool found = false;
		for (int i = 0;i<failedResourcesList.size();i++){
			if (failedResourcesList[i].compare(resourceName)==0){
				found = true;
				break;
			}
		}
		return found;
	}
	void SingletonFailedPreparation::removeResourceFromFailedPreparations(std::string resourceName){
		int idx = -1;
		for (int i = 0;i<failedResourcesList.size();i++){
			if (failedResourcesList[i].compare(resourceName)==0){
				idx = i;
				break;
			}
		}
		if (idx > -1){
			failedResourcesList.erase(failedResourcesList.begin()+idx);
		}
	}

///////////////////
///////////////////
///////////////////
//Get Directory count under given folder:
extern "C" float EXPORT_API GetNumberOfFoldersUnderFolder(const char *folderN){
	std::string folderName = folderN;
	if (folderName[folderName.length()-1]!='/'){
		folderName += "/";
	}

	SingletonAccessableResources *ar = SingletonAccessableResources::getInstance();
	std::string currentContent;
	std::string temp;
	std::map<std::string,char> container;
	for (int i = 0;i<ar->accessableResourcesList.size();i++){
		currentContent = ar->accessableResourcesList[i];
		size_t idx = currentContent.find(folderName);
		if (idx != std::string::npos){
			currentContent = currentContent.substr(idx+folderName.length());
			idx = currentContent.find("/");
			if (idx != std::string::npos){
				//its a folder
				currentContent = currentContent.substr(0,idx);
				container[currentContent] = 'a';
			}
		}
	}
	return container.size();
}

extern "C" const char* EXPORT_API FolderUnderFolderForNumber(const char *folderN,int number){
	std::string folderName = folderN;
	if (folderName[folderName.length()-1]!='/'){
		folderName += "/";
	}

	SingletonAccessableResources *ar = SingletonAccessableResources::getInstance();
	std::string currentContent = " ";
	std::string temp;
	std::map<std::string,char> container;
	for (int i = 0;i<ar->accessableResourcesList.size();i++){
		currentContent = ar->accessableResourcesList[i];
		size_t idx = currentContent.find(folderName);
		if (idx != std::string::npos){
			currentContent = currentContent.substr(idx+folderName.length());
			idx = currentContent.find("/");
			if (idx != std::string::npos){
				//its a folder
				currentContent = currentContent.substr(0,idx);
				currentContent = folderName + currentContent;
				container[currentContent] = 'a';
				if (container.size()==(number+1)){
					break;
				}
			}
		}
	}
	char *result = new char[currentContent.size()+1];
	strcpy(result, currentContent.c_str());
	return result;
}

extern "C" bool EXPORT_API ResourceAccessable(const char  *resourceName){
	std::string resourceNameString = resourceName;
	SingletonAccessableResources *ar = SingletonAccessableResources::getInstance();
	bool exists = false;
	for (int i = 0;i < ar->accessableResourcesList.size();i++){
		if (resourceNameString.find(ar->accessableResourcesList[i])!=std::string::npos){
			exists = true;
			break;
		}
	}
	return exists;
}

//remove resource from virtual file system:
extern "C" void EXPORT_API RemovePreparedResource(const char *resourceName){
	//remove it from Resource list
	std::string resourceNameString = resourceName;
	SingletonResource *sr = SingletonResource::getInstance();
	int idx = -1;
	for (int i = 0;i < sr->resourcesList.size();i++){
		if (sr->resourcesList[i].resourceName.find(resourceNameString)!=std::string::npos){
			idx = i;
			break;
		}
	}
	if (idx > -1){
		for(int i = 0;i < sr->resourcesList[idx].fileNames.size();i++){
			remove(sr->resourcesList[idx].fileNames[i].c_str());
		}
		sr->resourcesList.erase(sr->resourcesList.begin()+idx);
	}
	//remove from Preparation list:
	idx = -1;
	SingletonPreparation *sp = SingletonPreparation::getInstance();
	idx = sp->getIndexForResourceName(resourceName);
	if (idx > 0){
		for(int i = 0;i < sp->resourcesList[idx].resourceFiles.size();i++){
			remove(sp->resourcesList[idx].resourceFiles[i].c_str());
		}
		sp->resourcesList.erase(sp->resourcesList.begin()+idx);
	}
}

///////////////
///CallBacks///
///////////////

void onError(const char* file) {
	std::string fileFailed = file;
	SingletonPreparation *sp = SingletonPreparation::getInstance();
	int idxOfPreparation = sp->getIndexForResourceFile(fileFailed);
	if (idxOfPreparation > -1){
		std::string resourceName = sp->resourcesList[idxOfPreparation].resourceName;
		//remove already downlaoded files in given resource
		//remove entry from Preparation
		RemovePreparedResource(resourceName.c_str());
		SingletonFailedPreparation *sfp = SingletonFailedPreparation::getInstance();
		if (!sfp->isResourceFailedPreparation(resourceName)){
			sfp->failedResourcesList.push_back(resourceName);
		}
	}
}

void onLoaded(const char* file) {
	std::string fileLoaded = file;
	SingletonPreparation *sp = SingletonPreparation::getInstance();
	int idxOfPreparation = sp->getIndexForResourceFile(fileLoaded);
	if (idxOfPreparation > -1){
		sp->resourcesList[idxOfPreparation].idx++;
		if (sp->resourcesList[idxOfPreparation].resourceFiles.size() <= sp->resourcesList[idxOfPreparation].idx){
			//all resources have been downloaded clear

			//pass data to Resource tracking:
			SingletonResource *sr = SingletonResource::getInstance();
			Resource temp;
			temp.resourceName = sp->resourcesList[idxOfPreparation].resourceName;
			temp.fileNames = sp->resourcesList[idxOfPreparation].resourceFiles;
			sr->resourcesList.push_back(temp);
			
			//remove from failedPreparation tracking if it failed before:
			SingletonFailedPreparation::getInstance()->removeResourceFromFailedPreparations(temp.resourceName);

			std::string resourceName = sp->resourcesList[idxOfPreparation].resourceName.c_str();

			//remove entry from sp:
			sp->resourcesList.erase(sp->resourcesList.begin()+idxOfPreparation);
		}else{
			//there are resource files that still needs to be downloaded:
			std::string fileToDownloadLink = "/StreamingAssets/" + sp->resourcesList[idxOfPreparation].resourceFiles[sp->resourcesList[idxOfPreparation].idx];
			std::string filePath = sp->resourcesList[idxOfPreparation].resourceFiles[sp->resourcesList[idxOfPreparation].idx];

			emscripten_async_wget(
				fileToDownloadLink.c_str(), 
				filePath.c_str(),
				onLoaded,
				onError);
		}
	}else{
		//what?!
	}
}
///////////////

//0: resource not yet queued/prepared/failed;
//1: resource Failed Preparation! not ready to use
//2: resource already queued for preparing
//3: resource already prepared, ready to use
extern "C" int EXPORT_API GetStateOfResource( const char *resourceName ){
	SingletonPreparation *sp = SingletonPreparation::getInstance();
	int idx = sp->getIndexForResourceFile(resourceName);
	if (idx > 0){
		//2: resource already queued for preparing
		return 2;
	}
	SingletonResource *sr = SingletonResource::getInstance();
	if (sr->ResourceExists(resourceName)){
		//3: resource already prepared
		return 3;
	}

	SingletonFailedPreparation *sfp = SingletonFailedPreparation::getInstance();
	if (sfp->isResourceFailedPreparation(resourceName)){
		return 1;
	}

	return 0;
}
//preparation function entry point:
extern "C" void EXPORT_API PrepareResource( const char *resourceName ){
	if (GetStateOfResource(resourceName) > 1){
		//return if its queued or prepared already
		return;
	}

	ResourceBeingPrepared temp;
	temp.idx = 0;
	//temp.callBack = cb;
	temp.resourceName = resourceName;
	getResourceFilesForResourceFolder(temp.resourceName+"/",temp.resourceFiles);

	if (temp.resourceFiles.size()==0){
		return;
	}

	std::string fileToDownloadLink = "/StreamingAssets/" + temp.resourceFiles[temp.idx];
	std::string filePath = temp.resourceFiles[temp.idx];

	emscripten_async_wget(
		fileToDownloadLink.c_str(), 
		filePath.c_str(),
		onLoaded,
		onError);

	SingletonPreparation::getInstance()->resourcesList.push_back(temp);
	//1: resource is now queued for preparing
}

#endif